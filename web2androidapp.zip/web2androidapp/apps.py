from django.apps import AppConfig


class Web2AndroidappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "web2androidapp"
